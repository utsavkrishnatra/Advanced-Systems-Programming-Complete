#!/bin/bash
# This line tells the interpreter which shell to use.If we use shbang, we will be using bash interpreter

# THis command will check if the file sample.txt is present in the current working directory or not
if [! -e "sample.txt" ]; then
     # AS the file sample.txt doen't exist, create the following file
    touch sample.txt
    echo "sample.txt  has been created in the current directory."
    fi
else
   
    # THis command will check if the current user is the owner of the file or not using whoami command and comparing it with the sample.txt's owner extracted using stat command which extracts the file's username as specified using format specifier %U
    if [ "$(stat -c '%U' sample.txt)" = "$(whoami)" ]; then
        # It will check if the file has write permission or not
        if [ -w "sample.txt" ]; then
            # THIs command will append the contents of ls -1 as printed in one line into sample.txt using redirection operator from file sample.txt
            ls -1 >> sample.txt
            #this will print the contents into stdout
            echo "Contents of write added to the file sample.txt."
        else
        # if we don't have the right permission, then it will print the following line specifiying that the file doesn't have the right permissions.
            echo "Sorry, you don't have the write permission on sample.txt."
            # THIs command will set the  write permission of the file using chmod which will henceforth  give the write permission to the owner.
            chmod +w sample.txt
            echo "I am setting the write permission on sample.txt."
        fi
    else
        echo "You are not the current owner of file specified as sample.txt."
    
fi
