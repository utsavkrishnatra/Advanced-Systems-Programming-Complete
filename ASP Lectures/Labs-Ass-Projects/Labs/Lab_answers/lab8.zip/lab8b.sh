#!/bin/bash
# This line tells the interpreter which shell to use.If we use shbang, we will be using bash interpreter

# This line checks if number of arguments passed to the script is less than 1 or greater than 2, then it will show the error message, else it will proceed with the further commands in the script
if [ $# -lt 1 ] || [ $# -gt 2 ]; then
#prints the correct command
    echo "Please specify the command as : ./Countfiles.sh {path_to_directory} [provided_file_extension]"
    # exits from the script
    exit 1
fi

#takes into variable directory argv argument variable 1 from stdin
dir="$1"
#takes into variable extension argv argument variable 2 from stdin
ext="$2"

# this command will check if the directory exists or not
if [ ! -d "$dir" ]; then
#prints that directory is not found
    echo "Error: Directory not found."
#exits the command    
    exit 1
fi

# This command will check if the extension exists and if the extension is without dot(.), then dot(.) will be appended to it. This command will work with or without dot(.) in the extension.
if [ ! -z "$ext" ] && [[ "$ext" != .* ]]; then
# appends the dot to the extension if it doesn't have one
    ext=".$ext"
fi

if [ ! -z "$ext" ]; then
# If the extension exists, then  execute the wc -l command with .extension file
    nums=$(find "$dir" -type f -name "*$ext" | wc -l)
   
else
# If the extension doesn't exist, then directly execute the wc -l command
     nums=$(find "$dir" -type f | wc -l)
fi

#print number of extensions in the user given directory to the stdout
echo "Number of $ext files in $dir: $nums"
