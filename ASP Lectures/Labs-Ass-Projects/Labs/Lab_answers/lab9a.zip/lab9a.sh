#!/bin/bash
# commaneted code to tell the interpreter to use bash shell

# it checks whether number of arguments are equal to zero or not
if [ "$#" -eq 0 ]; then
    echo "ERR...:: Absence of input files...."
    exit 1
fi


# this function checks whether the given argument at 1st index is .txt extension or not
function isFile {
    if [ ! -f "$1" ] || [ "${1##*.}" != "txt" ]; then
        echo "ERR...:: The given '$1' argument isn't a .txt extension"
        exit 1
    fi
}

# variable defining the location to store the output file
appended_file_store="output.txt"


# checking for  the dest fl and cleaning the contents prior
if [ -f "$appended_file_store" ]; then
    > "$appended_file_store"
fi


#Looping thorough the  given input files and appending the contents if the fl
until [ -z "$1" ]; do
    # Code block to the existence and its appropriate extn
    isFile "$1"   
    cat "$1" >> "$appended_file_store"
    shift
done


# Showing successful operation
echo "Appended file stored in :  '$appended_file_store'."

