
#include <pthread.h>
//Hader for time
#include <time.h>
#include <stdio.h>  ////Headr fle fr  I/O
//Hder file for std library
#include <stdlib.h>
//Heder for therad in c


//Intialzing the variable with 100
#define arr_len 100

//Initlsig the ut_array1 Array of length 100
int ut_array1[arr_len];
//Initilisg the ut_array1 Array of length 100
int ut_array2[arr_len];
//Initilisg the ut_array1 Array of length 100
int ut_array3[arr_len];

// First thread with sum_1 function
void* sum_1(void* param) {
    int* ut_vArray = (int*)param;
    //dynamic memory allocation
    int* ut_varTotal = (int*)malloc(sizeof(int));
    *ut_varTotal = 0;
    //Iteration for adding elements to array
    for (int p = 0; p < arr_len; p++) {
        *ut_varTotal += ut_vArray[p];
    }
    pthread_exit((void*)ut_varTotal);
}

// second thread with sum_2 function
void* sum_2(void* param) {
    int* ut_vArray = (int*)param;
    //dynamic memory allocation
    int* ut_varTotal = (int*)malloc(sizeof(int));
    *ut_varTotal = 0;
    //Iteration for adding elements to array
    for (int q = 0; q < arr_len; q++) {
        *ut_varTotal += ut_vArray[q];
    }
    pthread_exit((void*)ut_varTotal);
}

// thread thread with sum_3 function
void* sum_3(void* param) {
    int* ut_vArray = (int*)param;
    //dynamic memory allocation
    int* ut_varTotal = (int*)malloc(sizeof(int));
    *ut_varTotal = 0;
    //Iteration for adding elements to array
    for (int s = 0; s < arr_len; s++) {
        *ut_varTotal += ut_vArray[s];
    }
    pthread_exit((void*)ut_varTotal);
}

//main function with for  the therad opration and smttl
int main() {
    srand(time(NULL));


    //iteration for making all arrays from 10-20
    for (int n = 0; n < arr_len; n++) {
        ut_array1[n] = rand() % 11 + 10;
        ut_array2[n] = rand() % 11 + 10;
        ut_array3[n] = rand() % 11 + 10;
    }

    //all the required thread creation
    pthread_t ut_pthread1, ut_pthread2, ut_pthread3;
    //thread1
    pthread_create(&ut_pthread1, NULL, sum_1, (void*)ut_array1);
     //thread2
    pthread_create(&ut_pthread2, NULL, sum_2, (void*)ut_array2);
     //thread3
    pthread_create(&ut_pthread3, NULL, sum_3, (void*)ut_array3);

   //writing opertions variable
    int* ut_ttal1;
    int* ut_ttal2;
    int* ut_ttal3;
    
    //thread_t_1
    pthread_join(ut_pthread1, (void**)&ut_ttal1);
      //thread_t_2
    pthread_join(ut_pthread2, (void**)&ut_ttal2);
      //thread_t_3
    pthread_join(ut_pthread3, (void**)&ut_ttal3);

    //  Sum for all the elmts
    int ut_resTtl = *ut_ttal1 + *ut_ttal2 + *ut_ttal3;

   // releasing the memory
    free(ut_ttal1);
    free(ut_ttal2);
    free(ut_ttal3);

  //printing the final sum
    printf("\n (Ttl/sum) = %d\n", ut_resTtl);

    return 0;
}

