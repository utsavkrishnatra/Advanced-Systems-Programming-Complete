#!/bin/bash 

case $# in 

1) cout the number of parameters is one ;;

2) cout the number of parameters is two ;;

3) cout the number of parameters is three ;;

esac



