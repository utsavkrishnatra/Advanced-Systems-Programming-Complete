#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

main()
{

int fd1=open("check420.txt", O_CREAT|O_RDWR,0666);
 

}
